package common;

public interface DatabaseOperations {
    // void insertData();
    void extractData();
}
